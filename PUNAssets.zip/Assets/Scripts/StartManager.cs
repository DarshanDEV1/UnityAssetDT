using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon;
using Photon.Realtime;
using TMPro;
using Photon.Pun;

interface Methods
{
    public abstract void OnClickConnectServer();
    public abstract void OnJoinedRoom();
    public abstract void OnConnected();
    public abstract void OnConnectedToMaster();
    public abstract void OnCreatedRoom();
    public abstract void Start();
    public abstract void Update();
    public abstract void OnClickCreateRoom();
    public abstract void OnClickJoinRoom();
    public abstract void Awake();
    public abstract void OnClickMultiPlayerSetup();
}
public class StartManager : MonoBehaviourPunCallbacks, Methods
{
    [SerializeField] TMP_InputField roomName;
    [SerializeField] GameObject GameMode;
    [SerializeField] GameObject MultiPlayerSetup;

    public void Awake()
    {
        GameMode.SetActive(true);
        MultiPlayerSetup.SetActive(false);
    }

    public void Start()
    {
        
    }

    public void Update()
    {
        
    }

    public void OnClickConnectServer()
    {
        PhotonNetwork.ConnectUsingSettings();
    }

    public override void OnJoinedRoom()
    {
        Debug.Log("Joined room successfully...");
        PhotonNetwork.LoadLevel("MultiPlayer");
    }

    public override void OnConnectedToMaster()
    {
        Debug.Log("Connected to master server...");
        GameMode.SetActive(false);
        MultiPlayerSetup.SetActive(true);
    }

    public override void OnCreatedRoom()
    {
        Debug.Log("Created a room successfully...");
    }

    public override void OnConnected()
    {
        Debug.Log("Connected...");
    }

    public void OnClickCreateRoom()
    {
        PhotonNetwork.CreateRoom(roomName.name, new RoomOptions { MaxPlayers = 2 }, null);
    }

    public void OnClickJoinRoom()
    {
        PhotonNetwork.JoinRoom(roomName.name, null);
    }

    public void OnClickMultiPlayerSetup()
    {
        OnClickConnectServer();
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        Debug.Log("Disconnected...");
    }
}
