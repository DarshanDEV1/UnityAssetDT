using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon;
using Photon.Pun;
using Photon.Realtime;

public class GameManager : MonoBehaviour
{
    [SerializeField] GameObject _myPlayer;
    [SerializeField] GameObject _obstacleBar;

    // Start is called before the first frame update
    void Start()
    {
        OnClickStartGame();
        var _networkPlayer = PhotonNetwork.Instantiate(_myPlayer.name, _myPlayer.transform.position, _myPlayer.transform.rotation);
        Color randomColor = RandomColor();
        _networkPlayer.GetComponent<SpriteRenderer>().color = randomColor;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClickExitGamePlay()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(0);
        PhotonNetwork.Disconnect();
    }

    private Color RandomColor()
    {
        var r = Random.Range(0f, 1f);
        var g = Random.Range(0f, 1f);
        var b = Random.Range(0f, 1f);

        return new Color(r, g, b, 1f);
    }

    public void OnClickStartGame()
    {
        InvokeRepeating("SpawnBars", 0f, 2f);
    }

    private void SpawnBars()
    {
/*        yield return new WaitForSeconds(2f);*/
        var value = Random.Range(-2f, 2f);
        var obj = Instantiate(_obstacleBar, new Vector2(12f, value), Quaternion.identity);
/*        yield return new WaitForSeconds(2f);*/
    }
}
