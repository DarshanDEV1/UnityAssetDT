using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon;
using Photon.Realtime;

public class PlayerController : MonoBehaviour, IPunObservable
{
    [SerializeField] GameObject _playerGameObject;
    [SerializeField] Joystick _joyStick;
    [SerializeField] PhotonView _me;

    public void Start()
    {
        _playerGameObject = gameObject;
        _joyStick = GameObject.FindGameObjectWithTag("Joystick").GetComponent<Joystick>();
        _me = gameObject.GetComponent<PhotonView>();
    }

    public void Update()
    {
        if(_me.IsMine)
        {
            PlayerMovement();
        }
    }
    public void PlayerMovement()
    {
        var x = _joyStick.Horizontal;
        var y = _joyStick.Vertical;

        Vector2 move = new Vector2(x, y);
        _playerGameObject.transform.Translate(move * Time.deltaTime * 4);
    }
    [PunRPC]
    private void MovePlayer(Vector3 newPosition)
    {
        transform.position = newPosition;
    }
    public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {
        if (stream.IsWriting)
        {
            Vector3 pos = transform.localPosition;
            stream.Serialize(ref pos);
        }
        else
        {
            Vector3 pos = Vector3.zero;
            stream.Serialize(ref pos);  // pos gets filled-in. must be used somewhere
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(collision.collider.tag);
    }

}
