* Fix spelling error
