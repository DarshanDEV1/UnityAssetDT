using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Game : MonoBehaviour
{
    public Transform[] _objectPositions;
    public GameObject[] _gameObjects;
    public GameObject _startPanel;
    public GameObject _winPanel;
    public int winCount;


    // Start is called before the first frame update
    void Start()
    {
        Shuffle();
        _startPanel.SetActive(true);
        _winPanel.SetActive(false);
        winCount = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if(winCount == 4)
        {
            _startPanel.SetActive(false);
            _winPanel.SetActive(true);
        }
    }

    public void Shuffle()
    {
        for (int i = _gameObjects.Length - 1; i > 0; i--)
        {
            // Pick a random index from 0 to i
            int j = Random.Range(0, i + 1);

            // Swap _gameObjects[i] and _gameObjects[j]
            GameObject temp = _gameObjects[i];
            _gameObjects[i] = _gameObjects[j];
            _gameObjects[j] = temp;
        }

        for (int i = 0; i < _gameObjects.Length; i++)
        {
            var _gameObject = Instantiate(_gameObjects[i]);
            _gameObject.transform.position = _objectPositions[i].position;
        }
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
