using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragAndDrop : MonoBehaviour
{
    private Vector3 screenPoint;
    private Vector3 offset;
    public Vector2 currentPosition;
    [SerializeField] private string gameObjectName;
    [SerializeField] private bool _isAssigned;
    [SerializeField] private Game _game;

    private void Start()
    {
        _game = GameObject.Find("Game").GetComponent<Game>();
        _isAssigned = false;
        gameObjectName = gameObject.name;
        Vector2 _my_Pos = transform.position;
        currentPosition = new Vector2(_my_Pos.x, _my_Pos.y);
    }

    private void OnMouseDown()
    {
        screenPoint = Camera.main.WorldToScreenPoint(transform.position);
        offset = transform.position - Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z));
    }

    private void OnMouseDrag()
    {
        Vector3 curScreenPoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z);
        Vector3 curPosition = Camera.main.ScreenToWorldPoint(curScreenPoint) + offset;
        transform.position = curPosition;
    }

    private void OnMouseUp()
    {
        // Perform actions on drop
        if(!_isAssigned)
        {
            transform.position = currentPosition;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == gameObject.tag)
        {
            _isAssigned = true;
            gameObject.transform.position = collision.transform.position;
            collision.GetComponent<SpriteRenderer>().color = Color.green;
            Material spriteMaterial = collision.GetComponent<SpriteRenderer>().material;
            Color spriteColor = spriteMaterial.color;
            spriteColor.a = 1f;
            _game.winCount += 1;
            Destroy(gameObject, 0.3f);
        }
    }
}
